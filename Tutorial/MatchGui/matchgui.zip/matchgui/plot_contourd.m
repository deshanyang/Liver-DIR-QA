function hlines=plot_contourd(contours,varargin)
%
% plot_contourd(contours,varargin)
% plot_contourd(ax,contours,varargin)
%
% Copyright: Deshan Yang, PhD 2016
%

if ishandle(contours)
	ax = contours;
	contours = varargin{1};
    if isempty(contours)
        return;
    end
    
	if nargin > 2
		varargin = varargin(2:end);
	else
		varargin = [];
	end
else
    ax= gca;

	if nargin < 2
		varargin = [];
	end
    if isempty(contours)
        return;
    end
    
end

N = length(contours);
hlines = [];

for k = 1:N
	xy = contours{k};
	if ~isempty(varargin)
% 		hlines = plot(ax,xy(1,:),xy(2,:),varargin{:});
        hlines = line(...
            'Parent'    , ax, ...
            'XData'     , xy(1,:), ...
            'YData'     , xy(2,:), ...
            varargin{:});
	else
		hlines = plot(ax,xy(1,:),xy(2,:));
	end
end

set(hlines,'hittest','off');
